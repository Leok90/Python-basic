# Python 내장함수 min
# 반복 가능한 자료형을 입력받아 그 최소값을 리턴

vMin01 = min([1, 2, 3])
vMin02 = min("python")
print(vMin01 , " / ", vMin02 )