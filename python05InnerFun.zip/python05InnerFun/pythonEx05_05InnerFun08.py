# Python 내장함수 eval
#  문자열을 실행한 결과값을 리턴

vEval01 = eval('1+2')
vEval02 = eval("'hi' + 'a'")
vEval03 = eval('divmod(4, 3)')
print(vEval01, " / ", vEval02, " / ", vEval03)