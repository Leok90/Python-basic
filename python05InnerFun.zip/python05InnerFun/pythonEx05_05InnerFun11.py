# Python 내장함수 hex
# 정수값을 입력받아 16진수(hexadecimal)로 변환

vHex01 = hex(234)
vHex02 = hex(3)
print(vHex01, " \ ", vHex02)