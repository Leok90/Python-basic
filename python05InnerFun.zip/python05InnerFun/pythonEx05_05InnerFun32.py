# Python 내장함수 type
# 입력값의 자료형이 무엇인지 알려주는 함수

vTuple01 = type("abc")
vTuple02 = type([ ])
vTuple03 = tuple((1, 2, 3))

print(vTuple01 , " / " , vTuple02, " / " , vTuple03)
