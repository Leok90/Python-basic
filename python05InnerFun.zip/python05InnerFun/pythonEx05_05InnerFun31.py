# Python 내장함수 tuple
# 반복 가능한 자료형을 입력받아 튜플 형태로 바꾸어 리턴

vTuple01 = tuple("abc")
vTuple02 = tuple([1, 2, 3])
vTuple03 = tuple((1, 2, 3))

print(vTuple01 , " / " , vTuple02, " / " , vTuple03)
