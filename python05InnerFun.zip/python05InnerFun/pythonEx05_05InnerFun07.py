# Python 내장함수 enumerate
# 순서가 있는 자료형(리스트, 튜플, 문자열)을 입력으로 받아 
# 인덱스 값을 포함하는 enumerate 객체를 리턴 .

for i, name in enumerate(['body', 'foo', 'bar']):
    print(i, name)

