# Python 내장함수 oct
# 정수 형태의 숫자를 8진수 문자열로 바꾸어 리턴

vOct01 = oct(34)
vOct02 = oct(12345)
print(vOct01 , " / ", vOct02 )