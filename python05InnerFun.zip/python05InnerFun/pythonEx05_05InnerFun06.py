# Python 내장함수 divmod
# a를 b로 나눈 몫과 나머지를 튜플 형태로 리턴 .

vDivmod01 = divmod(7, 3)
vDivmod02 = divmod(1.3, 0.2)

print(vDivmod01, "\n" , vDivmod02)
