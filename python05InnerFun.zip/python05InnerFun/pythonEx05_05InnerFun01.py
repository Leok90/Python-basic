# Python 내장함수 abs
vAbs01 = abs(3)
vAbs02 = abs(-3)
vAbs03 = abs(-1.2)
print(vAbs01," / ",vAbs02," / ", vAbs03)