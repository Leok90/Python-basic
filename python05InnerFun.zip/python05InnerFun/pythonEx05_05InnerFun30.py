# Python 내장함수 str
# 문자열 형태로 객체를 변환 리턴

vStr01 = str(3)
vStr02 = str('hi')
vStr03 = str('hi'.upper())

print(vStr01 , " / " , vStr02, " / " , vStr03)
print(type(vStr01))