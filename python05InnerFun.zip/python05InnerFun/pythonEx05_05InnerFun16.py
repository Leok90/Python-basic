# Python 내장함수 len
# 길이(요소의 전체 개수)를 리턴

vLen01 = len("python")

print(vLen01)