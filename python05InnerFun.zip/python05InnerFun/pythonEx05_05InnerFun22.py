# Python 내장함수 max
# 반복 가능한 자료형을 입력받아 그 최대값을 리턴

vMax01 = max([1, 2, 3])
vMax02 = max("python")
print(vMax01 , " / ", vMax02 )