# Python 내장함수 ord
# ord(c)는 문자의 아스키 코드값을 리턴하는 함수이다.
# (※ ord 함수는 chr 함수와 반대이다.)

vOrd01 =  ord('a')
vOrd02 =  ord('0')

print(vOrd01, " / " , vOrd02)
