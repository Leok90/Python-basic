# Python 내장함수 all
# 이 x가 모두 참이면 True, 
# 거짓이 하나라도 있 으면 False를 리턴
vAll01 = all([1, 2, 3])
vAll02 = all([1, 2, 3, 0])

print(vAll01," / ",vAll02)