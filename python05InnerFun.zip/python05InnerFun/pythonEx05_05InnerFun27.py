# Python 내장함수 pow
# pow(x, y)는 x의 y 제곱한 결과값을 리턴하는 함수이다


vPow01 =  pow(2, 4)
vPow02 =  pow(3, 3)

print(vPow01, " / " , vPow02)
