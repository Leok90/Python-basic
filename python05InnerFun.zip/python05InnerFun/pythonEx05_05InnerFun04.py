# Python 내장함수 chr
# 아스키(ASCII) 코드값을 입력으로 받아  
# 그 코드에 해당하는 문자를 출력
vChr01 = chr(97)
vChr02 = chr(48)
vChr03 = chr(65)

print(vChr01," / ",vChr02," / ",vChr03)